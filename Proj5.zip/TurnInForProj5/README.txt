﻿CS 431 Compilers Project 5 Readme
Nathan Moder and Mai Nou


Regarding program output:
* The output assembly code was tested and works in mars.
* If the program compiles “Program Compiled” will be printed to the console and the corresponding *.s file will be populated with assembly code.
* If the program does not compile “Compiler Error” will be printed to the console along with various error messages.
* Scope does not yet work correctly.
* Arrays and array declarations do not work correctly. Attempting to declare an array currently creates a single variable of the desired type.
* The working program one requests a user’s input, and computes the square of the input value and all previous numbers starting from 1, and also decrements the number to zero before printing the next square. (Output for 2 looks like : 1 0 4 3 2 1 0). After the input has been processed the program should output a set of strings regarding the value (mainly if the final number is 25 or not). Multiple repetitions of the string happen for some inputs because of fallthrough in switch statements.


The error checking successfully checks for the following errors:
* Declaring a variable more than once in the same scope 
* Assigning a REAL value to a variable of type INT 
* Assigning a STRING literal to a variable of type INT, REAL, or BOOLEAN 
* Attempting to use a variable of type STRING for arithmetic operations including add (+), multiplication (*), incrementing (++), and decrementing (--) 

However, the error checking is only working for one level of nested scopes. We kept a global variable that tracks the parent of the variable (i.e. a parent can be a method, if, else, while, for, switch statements). For example the error checking for scope would fail with a code such as :
 
 VOID MAIN()
{
        c := "The number is 36" ;
        d := "You should not see this." ;
        j : INT ;
        PUT(z) ;
        y := GET() ;
        FOR(INT i := 1 ; i <= y ; i++)
        {
                x := i * i;
                PUT(x) ;
                j := x - 1 ;
                WHILE(j >= 0)
                {
                        PUT(j) ;
                        j := j - 1;
                }
        }
}


The scope is currently able to check for one level of nested scope. The error checker would identify as an error “j has not been declared” because the code currently only checks for one additional layer of scope. 


Another error checking that has not been implemented is checking errors with arrays (for example, checking if an array index is out of bounds).