﻿CS 431 Compilers Project 5 Readme
Nathan Moder and Mai Nou


Regarding program output:
* The output assembly code was tested and works in mars.
* If the program compiles “Program Compiled” will be printed to the console and the corresponding *.s file will be populated with assembly code.
* If the program does not compile “Compiler Error” will be printed to the console along with various error messages.
* Arrays and array declarations do not work correctly. Attempting to declare an array currently creates a single variable of the desired type.
* The working program one requests a user’s input, and computes the square of the input value and all previous numbers starting from 1, and also decrements the number to zero before printing the next square. (Output for 2 looks like : 1 0 4 3 2 1 0). After the input has been processed the program should output a set of strings regarding the value (mainly if the final number is 25 or not). Multiple repetitions of the string happen for some inputs because of fallthrough in switch statements.


The error checking successfully checks for the following errors:
* Assigning a REAL value to a variable of type INT 
* Assigning a STRING literal to a variable of type INT, REAL, or BOOLEAN 
* Attempting to use a variable of type STRING for arithmetic operations including add (+), multiplication (*), incrementing (++), and decrementing (--) 
* Declaring a void method and having the method return something 
* Detecting the scope of a variable - if a variable is redeclared in the same scope, it should generate an error stating that the variable was already declared in the method 
* Attempting to use a variable that has not be declared 
* Attempting to increment a string literal or a boolean variable