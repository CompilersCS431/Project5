package ProjFive;

import ProjFive.lexer.*;
import ProjFive.node.*;
import ProjFive.parser.*;
import java.io.*;
import java.util.ArrayList;

public class Main{

   public static void main(String[] arguments){
   for(int i = 0 ; i < arguments.length ; i+=2)
   {
      try{
            BufferedWriter write = new BufferedWriter(new FileWriter(arguments[i+1]));
            Lexer lexer = new Lexer(new PushbackReader
                  (new InputStreamReader(new FileInputStream(arguments[i])), 1024));

			
            Parser parser = new Parser(lexer);	
            Start ast = parser.parse();
            PrintTree t = new PrintTree();
            ast.apply(t);
            ArrayList<String> errors = t.error ;
            if(errors.size() > 0)
            {
                System.out.println("Compiler Error") ;
                for(int j = 0 ; j < errors.size() ; j++)
                {
                    System.out.println(errors.get(j));
                }
                System.exit(0) ;
            }
            else
            {
                SecondPass s = new SecondPass(t.symbolTable);
                ast.apply(s);

                //System.out.println(s.dataPart + s.codePart) ;
				System.out.println("Program Compiled") ;
                write.write(s.dataPart + s.codePart) ;
				write.close() ;
            }
            if(errors.size() > 0)
            {
                System.out.println("Compiler Error") ;
                for(int j = 0 ; j < errors.size() ; j++)
                {
                    System.out.println(errors.get(j));
                }
                System.exit(0) ;
            }
      }
      catch(Exception e){ 
			System.out.println("I am error") ;
			System.out.println("NOT VALID: " + e.getMessage());
	   }
   }
   }
}
			
