﻿CS 431 Compilers Final Project Readme
Nathan Moder and Mai Nou


Regarding program output:
* The output assembly code was tested and works in mars.
* If the program compiles “Program Compiled” will be printed to the console and the corresponding *.s file will be populated with assembly code.
* If the program does not compile “Compiler Error” will be printed to the console along with various error messages.
* Error when trying to load doubles. Most things with double probably do not work properly. 
* Methods with more than four arguments do not work. This will produce a register error. 
* Declaring an object inside a class or method, besides MAIN, may not work correctly.
* Main must declared in all capital letters (MAIN).
* The test program will print out a series of numbers to test array declarations and storage. Then the program will prompt to input and return 
  the first input value raised to the second input value. After that, the program doubles the result. The program will then prompt for another
  input and calculate the factorial of the input and print it. (Recursion works!) Then it will prompt another input and return a value based on
  the input using a switch statement. Prompt for another input and will return the value after testing a while loop. The result from this will
  be printed twice. Prompts for another input and creates an object using that input and returns values based off the input caculated from
  the class methods. Prompts for anothe input and uses the input to create an object of a different class and returns a few values based on the
  input. 


The error checking successfully checks for the following errors:
* Assigning a REAL value to a variable of type INT 
* Assigning a STRING literal to a variable of type INT, REAL, or BOOLEAN 
* Attempting to use a variable of type STRING for arithmetic operations including add (+), multiplication (*), incrementing (++), and decrementing (--) 
* Declaring a void method and having the method return something 
* Detecting the scope of a variable - if a variable is redeclared in the same scope, it should generate an error stating that the variable was already declared in the method 
* Attempting to use a variable that has not be declared 
* Attempting to increment a string literal or a boolean variable
* Mismatched paramters/arguments when making method calls will generate a mismatched arguments error.
* Declaring an object of a class that has not been declared yet.
* Incorrect return types.
* We check for errors in both PrintTree and SecondPass, so some erorrs will only show up if there were no errors found in PrintTree. If errors were 
  found in PrintTree, the program will print out all the errors from PrintTree and exit. 